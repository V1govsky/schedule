package ru.ssau.shedule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SheduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
